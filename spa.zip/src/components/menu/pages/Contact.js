import React, {Component} from "react";

class Contact extends Component {
    render() {
        return (
            <div>

                <h2>Есть вопросы?</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid amet dolore eligendi, exercitationem itaque necessitatibus, nobis officia praesentium quasi quia quos, sequi sunt tempora totam unde voluptate voluptates! Non, omnis!</p>
            </div>
        )
    }
}

export default Contact;