import React, {Component} from "react";

class MainTicTacToe extends Component {
    render() {
        return (
            <div>
                <h1>Крестики-нолики</h1>
            </div>
        )
    }
}
export default MainTicTacToe;