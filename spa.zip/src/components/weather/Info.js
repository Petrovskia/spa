import React, {Component} from "react";

class Info extends Component {
    render() {
        return (
            <div>
                <h2>Приложение для определения погоды</h2>
                <p>Узнай погоду в своем городе и не только</p>
            </div>
        )
    }
}

export default Info;