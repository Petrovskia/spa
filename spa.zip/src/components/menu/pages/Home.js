import React, {Component} from "react";

class Home extends Component {
    render() {
        return (
            <div>
                <h2>Домашняя страница</h2>
                <p>Добро пожаловать</p>
            </div>
        )
    }
}

export default Home;