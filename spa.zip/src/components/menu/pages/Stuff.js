import React, {Component} from "react";

class Stuff extends Component {
    render() {
        return (
            <div>
                <h2>Наши сотрудники</h2>
                <ul>
                    <li>Марк.</li>
                    <li>Дмитрий</li>
                    <li>Михаил</li>
                    <li>Светлана</li>
                    <li>Екатерина</li>
                    <li>Дарья</li>
                    <li>Роман</li>
                    <li>Денис</li>
                </ul>
            </div>
        )
    }
}

export default Stuff;